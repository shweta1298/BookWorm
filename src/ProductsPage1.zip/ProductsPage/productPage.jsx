import ProductList from "./ProductList";
import React, { Component } from "react";

class ProductPage extends Component {
	render() {
		return (
			<div>
				<ProductList></ProductList>
			</div>
		);
	}
}

export default ProductPage;
